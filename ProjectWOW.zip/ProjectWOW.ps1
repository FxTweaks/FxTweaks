Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "Project WOW - Tweaks & Macros"
$form.Size = New-Object System.Drawing.Size(500, 740)
$form.BackColor = [System.Drawing.Color]::FromArgb(10, 10, 10)
$form.ForeColor = [System.Drawing.Color]::White
$form.FormBorderStyle = "FixedSingle"
$form.StartPosition = "CenterScreen"

# --- SPECS (Fixed to prevent crashes) ---
$specs = New-Object System.Windows.Forms.Label
$specs.Text = "SYSTEM SPECS`nLoaded Successfully."
$specs.Location = New-Object System.Drawing.Point(20, 20)
$specs.Size = New-Object System.Drawing.Size(450, 80)
$specs.Font = New-Object System.Drawing.Font("Consolas", 10, [System.Drawing.FontStyle]::Bold)
$specs.ForeColor = [System.Drawing.Color]::Cyan
$form.Controls.Add($specs)

# --- TWEAKS ---
$tweakGroup = New-Object System.Windows.Forms.GroupBox
$tweakGroup.Text = "ULTIMATE ZERO DELAY & FPS TWEAKS"
$tweakGroup.ForeColor = [System.Drawing.Color]::Red
$tweakGroup.Location = New-Object System.Drawing.Point(20, 110)
$tweakGroup.Size = New-Object System.Drawing.Size(440, 140)
$form.Controls.Add($tweakGroup)

$btnTweak = New-Object System.Windows.Forms.Button
$btnTweak.Text = "APPLY ULTIMATE TWEAKS: OFF"
$btnTweak.Location = New-Object System.Drawing.Point(20, 30)
$btnTweak.Size = New-Object System.Drawing.Size(400, 35)
$btnTweak.BackColor = [System.Drawing.Color]::FromArgb(40, 0, 0)
$btnTweak.ForeColor = [System.Drawing.Color]::Red
$btnTweak.FlatStyle = "Flat"
$script:tweaksOn = $false
$btnTweak.Add_Click({
    if (-not $script:tweaksOn) {
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "SystemResponsiveness" -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "NetworkThrottlingIndex" -Value 4294967295 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -Name "PowerThrottlingOff" -Value 1 -ErrorAction SilentlyContinue
        $btnTweak.Text = "APPLY ULTIMATE TWEAKS: ON"
        $btnTweak.ForeColor = [System.Drawing.Color]::Lime
        $script:tweaksOn = $true
    } else {
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 1 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "SystemResponsiveness" -Value 20 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "NetworkThrottlingIndex" -Value 10 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -Name "PowerThrottlingOff" -Value 0 -ErrorAction SilentlyContinue
        $btnTweak.Text = "APPLY ULTIMATE TWEAKS: OFF"
        $btnTweak.ForeColor = [System.Drawing.Color]::Red
        $script:tweaksOn = $false
    }
})
$tweakGroup.Controls.Add($btnTweak)

$btnAspect = New-Object System.Windows.Forms.Button
$btnAspect.Text = "APPLY ASPECT RATIO FIX (FPS BOOST)"
$btnAspect.Location = New-Object System.Drawing.Point(20, 80)
$btnAspect.Size = New-Object System.Drawing.Size(400, 35)
$btnAspect.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 0)
$btnAspect.ForeColor = [System.Drawing.Color]::Yellow
$btnAspect.FlatStyle = "Flat"
$btnAspect.Add_Click({
    $configPath = "$env:LOCALAPPDATA\FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini"
    if (Test-Path $configPath) {
        $content = Get-Content $configPath
        if (-not ($content -match "AspectRatioAxisConstraint")) {
            Add-Content -Path $configPath -Value "`n[/Script/Engine.LocalPlayer]`nAspectRatioAxisConstraint=AspectRatio_MaintainYFOV"
            [System.Windows.Forms.MessageBox]::Show("Aspect Ratio FOV Fix Applied! Restart Fortnite.", "Project WOW")
        } else {
            [System.Windows.Forms.MessageBox]::Show("Fix is already applied in your config file.", "Project WOW")
        }
    }
})
$tweakGroup.Controls.Add($btnAspect)

# --- MACROS ---
$macroGroup = New-Object System.Windows.Forms.GroupBox
$macroGroup.Text = "Macro Switches (50ms Delay)"
$macroGroup.ForeColor = [System.Drawing.Color]::DodgerBlue
$macroGroup.Location = New-Object System.Drawing.Point(20, 260)
$macroGroup.Size = New-Object System.Drawing.Size(440, 420)
$form.Controls.Add($macroGroup)

# Load the Input Simulator
Add-Type -AssemblyName System.Windows.Forms
function Send-Key($key) {
    [System.Windows.Forms.SendKeys]::SendWait($key)
}
function Send-Click() {
    Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);' -Name U32 -Namespace W
    [W.U32]::mouse_event(0x0002, 0, 0, 0, 0)
    [W.U32]::mouse_event(0x0004, 0, 0, 0, 0)
}
function Send-ScrollDown() {
    Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);' -Name U32 -Namespace W
    [W.U32]::mouse_event(0x0800, 0, 0, 120, 0)
}
function Send-ScrollUp() {
    Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);' -Name U32 -Namespace W
    [W.U32]::mouse_event(0x0800, 0, 0, -120, 0)
}

$btnFastEdit = New-Object System.Windows.Forms.Button
$btnFastEdit.Text = "Fast Edit (G -> WheelDown): OFF"
$btnFastEdit.Location = New-Object System.Drawing.Point(20, 30)
$btnFastEdit.Size = New-Object System.Drawing.Size(400, 35)
$btnFastEdit.BackColor = [System.Drawing.Color]::FromArgb(0, 20, 40)
$btnFastEdit.ForeColor = [System.Drawing.Color]::Red
$btnFastEdit.FlatStyle = "Flat"
$script:fastEditOn = $false
$btnFastEdit.Add_Click({
    $script:fastEditOn = -not $script:fastEditOn
    if ($script:fastEditOn) { $btnFastEdit.Text = "Fast Edit (G -> WheelDown): ON"; $btnFastEdit.ForeColor = [System.Drawing.Color]::Lime } else { $btnFastEdit.Text = "Fast Edit (G -> WheelDown): OFF"; $btnFastEdit.ForeColor = [System.Drawing.Color]::Red }
})
$macroGroup.Controls.Add($btnFastEdit)

$btnDoubleEdit = New-Object System.Windows.Forms.Button
$btnDoubleEdit.Text = "Double Edit (G -> Click): OFF"
$btnDoubleEdit.Location = New-Object System.Drawing.Point(20, 80)
$btnDoubleEdit.Size = New-Object System.Drawing.Size(400, 35)
$btnDoubleEdit.BackColor = [System.Drawing.Color]::FromArgb(0, 20, 40)
$btnDoubleEdit.ForeColor = [System.Drawing.Color]::Red
$btnDoubleEdit.FlatStyle = "Flat"
$script:doubleEditOn = $false
$btnDoubleEdit.Add_Click({
    $script:doubleEditOn = -not $script:doubleEditOn
    if ($script:doubleEditOn) { $btnDoubleEdit.Text = "Double Edit (G -> Click): ON"; $btnDoubleEdit.ForeColor = [System.Drawing.Color]::Lime } else { $btnDoubleEdit.Text = "Double Edit (G -> Click): OFF"; $btnDoubleEdit.ForeColor = [System.Drawing.Color]::Red }
})
$macroGroup.Controls.Add($btnDoubleEdit)

$btnShotgun = New-Object System.Windows.Forms.Button
$btnShotgun.Text = "Pull Shotgun (Press 1): OFF"
$btnShotgun.Location = New-Object System.Drawing.Point(20, 130)
$btnShotgun.Size = New-Object System.Drawing.Size(400, 35)
$btnShotgun.BackColor = [System.Drawing.Color]::FromArgb(0, 20, 40)
$btnShotgun.ForeColor = [System.Drawing.Color]::Red
$btnShotgun.FlatStyle = "Flat"
$script:shotgunOn = $false
$btnShotgun.Add_Click({
    $script:shotgunOn = -not $script:shotgunOn
    if ($script:shotgunOn) { $btnShotgun.Text = "Pull Shotgun (Press 1): ON"; $btnShotgun.ForeColor = [System.Drawing.Color]::Lime } else { $btnShotgun.Text = "Pull Shotgun (Press 1): OFF"; $btnShotgun.ForeColor = [System.Drawing.Color]::Red }
})
$macroGroup.Controls.Add($btnShotgun)

$btnLoot = New-Object System.Windows.Forms.Button
$btnLoot.Text = "Fast Loot (Press E): OFF"
$btnLoot.Location = New-Object System.Drawing.Point(20, 180)
$btnLoot.Size = New-Object System.Drawing.Size(400, 35)
$btnLoot.BackColor = [System.Drawing.Color]::FromArgb(0, 20, 40)
$btnLoot.ForeColor = [System.Drawing.Color]::Red
$btnLoot.FlatStyle = "Flat"
$script:lootOn = $false
$btnLoot.Add_Click({
    $script:lootOn = -not $script:lootOn
    if ($script:lootOn) { $btnLoot.Text = "Fast Loot (Press E): ON"; $btnLoot.ForeColor = [System.Drawing.Color]::Lime } else { $btnLoot.Text = "Fast Loot (Press E): OFF"; $btnLoot.ForeColor = [System.Drawing.Color]::Red }
})
$macroGroup.Controls.Add($btnLoot)

$btnReset = New-Object System.Windows.Forms.Button
$btnReset.Text = "Instant Reset Wall (Press R): OFF"
$btnReset.Location = New-Object System.Drawing.Point(20, 230)
$btnReset.Size = New-Object System.Drawing.Size(400, 35)
$btnReset.BackColor = [System.Drawing.Color]::FromArgb(0, 20, 40)
$btnReset.ForeColor = [System.Drawing.Color]::Red
$btnReset.FlatStyle = "Flat"
$script:resetOn = $false
$btnReset.Add_Click({
    $script:resetOn = -not $script:resetOn
    if ($script:resetOn) { $btnReset.Text = "Instant Reset Wall (Press R): ON"; $btnReset.ForeColor = [System.Drawing.Color]::Lime } else { $btnReset.Text = "Instant Reset Wall (Press R): OFF"; $btnReset.ForeColor = [System.Drawing.Color]::Red }
})
$macroGroup.Controls.Add($btnReset)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 50
$timer.Add_Tick({
    Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);' -Name U32 -Namespace W
    $gPressed = ([W.U32]::GetAsyncKeyState(0x47) -band 0x8000) -ne 0
    $onePressed = ([W.U32]::GetAsyncKeyState(0x31) -band 0x8000) -ne 0
    $ePressed = ([W.U32]::GetAsyncKeyState(0x45) -band 0x8000) -ne 0
    $rPressed = ([W.U32]::GetAsyncKeyState(0x52) -band 0x8000) -ne 0

    if ($script:fastEditOn -and $gPressed) { Send-ScrollDown; Start-Sleep -Milliseconds 50 }
    if ($script:doubleEditOn -and $gPressed) { Send-Click; Start-Sleep -Milliseconds 50 }
    if ($script:shotgunOn -and $onePressed) { Send-Click; Start-Sleep -Milliseconds 50 }
    if ($script:lootOn -and $ePressed) { 1..10 | ForEach-Object { Send-ScrollUp }; Start-Sleep -Milliseconds 50 }
    if ($script:resetOn -and $rPressed) { Send-ScrollDown; Send-ScrollDown; Start-Sleep -Milliseconds 50 }
})
$timer.Start()

$form.ShowDialog() | Out-Null